Saleor
======

An open source storefront written in Python.


Documentation has moved!
------------------------

Saleor documentation has moved to https://docs.getsaleor.com
