from ...extensions import ConfigurationTypeField
from ...graphql.core.enums import to_enum

ConfigurationTypeFieldEnum = to_enum(ConfigurationTypeField)
